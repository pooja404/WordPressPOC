    <footer class="nopadding">
    <div class=" row footer-yellow nopadding">

      <div class="col-md-12 col-sm-12 col-xs-12 nopadding ">
        <div>
          <img class="col-md-12 col-sm-12 col-xs-12 nopadding" src="<?php echo get_stylesheet_directory_uri(); ?>/images/upperfooter.png">
        </div>
        <div class="col-md-6  col-sm-5 " style="padding-top: 70px; padding-left: 20px">
          <img class="col-md-12 col-sm-12 nopadding" alt="Driscoll's Only the Finest Berries"
            src="<?php echo get_stylesheet_directory_uri(); ?>/images/footerlogo.png" style="width: 100%;">
        </div>
        <div class="col-md-6 col-sm-6 col-xs-6" style="padding-top: 108px;">

          <div class="col-md-6 col-sm-6 col-xs-6">
            <nav class="nav-list">
              <ul>
                <li><a href="#">Contactanos</a></li>
                <li><a href="#">Telefono</a></li>
                <li><a href="#">Mail</a></li>
                <li><a href="#">Aviso de Privacidad<a></li>
              </ul>
            </nav>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6  socialicondiv" style="margin-left: 207px;">
            <nav class="nav-list">
              <ul>
                <li class="social-li">
                  <a class="col-md-12 col-sm-12 col-xs-12 nopadding" href="https://www.facebook.com/driscollsberries"
                    target="_blank"><i class="fa fa-facebook-square fa-2x fa-border" aria-hidden="true"></i></a>
                  <br></li>
                <li class="social-li insta-class">
                  <a class="col-md-12 col-sm-12 col-xs-12 nopadding" href="https://www.instagram.com/driscollsberry"
                    target="_blank"><i class="fa fa-instagram fa-2x fa-border"></i></a>
                  <br></li>
            </nav>
          </div>
        </div>
      </div>
      <div class="col-md-12 col-sm-12 col-xs-12 row nopadding">
        <div class=footer-color>
          <p class="small">© 2020 Driscoll's, Inc. All rights reserved.</p>
        </div>
      </div>
  </footer>
<?php wp_footer(); ?>
</body>
</html>